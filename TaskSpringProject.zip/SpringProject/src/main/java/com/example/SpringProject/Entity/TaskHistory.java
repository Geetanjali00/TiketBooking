package com.example.SpringProject.Entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "task_history")
public class TaskHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "Task_History_Id", length = 50)
    private int taskHistoryId;
    private int TaskId;
    private String taskName;
    private String taskDetail;
    @Column(name="DATE")

    LocalDate date= LocalDate.now();


    public TaskHistory() {
    }

    public TaskHistory(int taskHistoryId, int taskId, String taskName, String taskDetail, LocalDate date) {
        this.taskHistoryId = taskHistoryId;
        TaskId = taskId;
        this.taskName = taskName;
        this.taskDetail = taskDetail;
        this.date = date;
    }

    public int getTaskHistoryId() {
        return taskHistoryId;
    }

    public void setTaskHistoryId(int taskHistoryId) {
        this.taskHistoryId = taskHistoryId;
    }

    public int getTaskId() {
        return TaskId;
    }

    public void setTaskId(int taskId) {
        TaskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDetail() {
        return taskDetail;
    }
    public void setTaskDetail(String taskDetail) {
        this.taskDetail = taskDetail;
    }
    public LocalDate getDate() {
            return date;
    }

        public void setDate(LocalDate date) {
            this.date = date;
        }


    @Override
    public String toString() {
        return "TaskHistory{" +
                "taskHistoryId=" + taskHistoryId +
                ", TaskId=" + TaskId +
                ", taskName='" + taskName + '\'' +
                ", taskDetail='" + taskDetail + '\'' +
                ", date=" + date +
                '}';
    }
}