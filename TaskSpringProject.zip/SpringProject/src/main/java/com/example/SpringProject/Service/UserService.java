package com.example.SpringProject.Service;

import com.example.SpringProject.Entity.User;
import com.example.SpringProject.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    public User addUser(User user) {
        return userRepo.save(user);
    }

//  public User updateUser(int id, User user) throws ResourceNotFoundException {
//    User existingUser = userRepo.findById(id)
//            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
//    return userRepo.save(user);
//}


//    public void deleteUser(int id) {
//        userRepo.deleteById(id);
//    }
}
