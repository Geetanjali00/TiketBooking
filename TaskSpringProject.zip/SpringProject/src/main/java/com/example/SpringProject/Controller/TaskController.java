package com.example.SpringProject.Controller;

import com.example.SpringProject.Entity.Task;
import com.example.SpringProject.Entity.TaskHistory;
import com.example.SpringProject.Service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/task")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping("/save")
    public Task addTask(@RequestBody Task task){
        return taskService.addTask(task);
    }
    @GetMapping(path="getAllTask")
    public List<Task> getTask(){
        return taskService.getAllTasks();
    }

    @PutMapping (path="/update/{taskid}")
    public Task updateTask(@RequestBody Task task,@PathVariable int taskid){
        return taskService.updateTask(task, taskid);
    }
    @DeleteMapping  (path="/delete/{id}")
    public ResponseEntity<String> deleteTask(@PathVariable(value="id") int id){
        TaskHistory savedTaskHistory = taskService.deleteTask(id, "user"); // Pass the user who performed the delete operation

        if (savedTaskHistory != null) {
            return ResponseEntity.ok("Task history saved successfully"); //ResponseEntity is a powerful and flexible class that allows us to handle HTTP responses in a convenient and consistent way in our Spring applications.
        } else {
            return ResponseEntity.badRequest().body("Failed to save task history");
        }
    }
    @PostMapping (path="/priority/{taskid}")
    public Task addPriority(@PathVariable int taskid, @RequestParam boolean priority){
        return taskService.addPriority(taskid, priority);
    }
    @PutMapping (path="/targetDate/{taskid}")
    public Task updateTargetDate(@PathVariable int taskid, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate targetDate){
        return taskService.updateTargetDate(taskid, targetDate);
    }
}


